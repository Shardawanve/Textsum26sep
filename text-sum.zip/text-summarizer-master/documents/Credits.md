[Text summarization in 5 steps using NLTK](https://becominghuman.ai/text-summarization-in-5-steps-using-nltk-65b21e352b65)

[Extract text from a webpage using BeautifulSoup and Python](https://matix.io/extract-text-from-webpage-using-beautifulsoup-and-python/)

[Automate boring stuff chap 12 and 15](https://automatetheboringstuff.com/)

[State-of-the-art Natural Language Processing for TensorFlow 2.0 and PyTorch.](https://github.com/huggingface/transformers)
