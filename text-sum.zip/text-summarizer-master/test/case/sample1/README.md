# sample1 folder
`sample1.docx`, `sample1.odt`, `sample1.txt` are about [The Unlicense](https://choosealicense.com/licenses/unlicense/)
