# sample2 folder
`sample2.docx`, `sample2.odt`, `sample2.txt` are about [GNU GPLv3](https://choosealicense.com/licenses/gpl-3.0/)
