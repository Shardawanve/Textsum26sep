# sample3 folder
All samples are lorem ipsum, hence these are not English documents but Text-Summarizer should work and return nothing or return unmeaningful characters.
