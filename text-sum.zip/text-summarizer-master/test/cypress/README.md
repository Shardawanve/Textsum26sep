# Installation and usage

Documentation for Cypress can be found [here](https://docs.cypress.io/guides/getting-started/installing-cypress.html#System-requirements)

# File structure

In /test/cypress/ 

Example file for testing is in fixtures folder. Test file is in integration folder.
