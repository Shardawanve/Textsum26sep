# Make nltk downloads missing components
import nltk
nltk.download('stopwords')
nltk.download('punkt')