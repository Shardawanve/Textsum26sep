from setuptools import setup
setup(name='abberivator_flow',
version='0.0.2',
description='nan',
url='#',
author='dinhanhx',
author_email='dinhanhx@gmail.com',
license='The Unlicensed',
packages=['abberivator_flow'],
zip_safe=False)
